// Name: Liam Loeffel
// Program: Main Program
// Description: The game is Connect FourThe user is prompted to input a value 
//              between 1-7 to tell the computer to add a disc to a particular column. 
//              If a player wins the game then the program ends.

/*  insert comments here */
#include "C4Board.h"   // class definition for C4Board used below

int main() {
  C4Board c4;//instantiate an instance of a C4Board object
  c4.play();        // play game!!
}
