Project 04: Path Finding
========================

This project implements a [Dijkstra's Algorithm] to perform rudimentary path
finding on a 2D tile-based map.

[Dijkstra's Algorithm]: https://en.wikipedia.org/wiki/Dijkstra%27s_algorithm


Input
-----

    TILES_N
    TILE_NAME_0	TILE_COST_0
    ...
    TILE_NAME_N-1	TILE_COST_N-1

    MAP_ROWS MAP_COLUMNS
    TILE_0_0    ...
    ...

    TRAVELER_START_ROW TRAVELER_START_COL
    TRAVELER_END_ROW   TRAVELER_END_COL

Output
------

    Cost
    [(ROW_0, COL_0), ...]
Writeup:
|N    |Elapsed Time|Memory Usage|
|-----|------------|------------|
|10   |0.48+0.48+.47+.47+.47|83,924|
|20   |0.48+0.49+0.48+0.48+0.48|88,228|
|50   |0.57+0.57+0.57+.56+0.56|115,220|
|100  |0.69+0.69+0.68+0.69+0.69|207,268|
|200  |1.44+1.44+1.44+1.44+1.43|572,388|
|500  |7.65+7.65+7.62+7.64+7.65|3,119,012|
|1000 |


How did you represent the graph?
    We stored the graph as an adjacency matrix 
    except the array was flatenned due to the rectangular properties of the map.
    The visited nodes were stored as {distance, index} pairs.
What is complexity of your implementation of Dijkstra's Algorithm?
    The complexity of our algorithm is O(E+Vlog(V))
    where V is the number of verticies, and E is the number of edges.
    We used a priority queue for storing the frontier, 
    and then used vectors for storing other things like our graph, marked, and path.
How well does your implementation scale?
    
