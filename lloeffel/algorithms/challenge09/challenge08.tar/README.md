COMPILE:
	g++ -o solution solution.cpp
	OR
	make

EXECUTE:
	./solution < [input file]

OUTPUTS:
	seq1.txt
		4
		-1
		-7
		2
		-2
		2
		-1
		6
		2
	seq2.txt:
		4
		3
		2
		-5
		5
		3
		3
		-4
		-1
		0
		-10
	s1ands2.txt:
		965
